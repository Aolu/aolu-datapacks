function aolu_staffs_n_tomes:spells/shadow/dark_mass_cast
function aolu_staffs_n_tomes:spells/shadow/dark_mass_cast
function aolu_staffs_n_tomes:spells/shadow/dark_mass_cast
function aolu_staffs_n_tomes:spells/shadow/dark_mass_cast
function aolu_staffs_n_tomes:spells/shadow/dark_mass_cast
