 
kill @s